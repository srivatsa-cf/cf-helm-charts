{{- define "cf-codenavigator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{- define "cf-codenavigator.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- define "cf-codenavigator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cf-codenavigator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "cf-codenavigator.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "cf-codenavigator.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{- define "cf-codenavigator.annotations" -}}
{{- $ctx := .ctx -}}
{{- $extra := .extra | default dict -}}
{{- $all := merge (deepCopy ($ctx.Values.commonAnnotations | default dict)) (deepCopy $extra) -}}
{{- with $all }}
annotations:
{{ toYaml . | indent 2 }}
{{- end -}}
{{- end }}

{{- define "cf-codenavigator.image" -}}
{{- if .Values.image.digest -}}
{{- printf "%s@%s" .Values.image.repository .Values.image.digest -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default (printf "cf-codenavigator-%s" .Chart.AppVersion)) -}}
{{- end -}}
{{- end }}

{{- define "cf-codenavigator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "cf-codenavigator.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- .Values.serviceAccount.name -}}
{{- end -}}
{{- end }}

{{- define "cf-codenavigator.podSecurityContext" -}}
{{- $ctx := .Values.podSecurityContext | default dict -}}
{{- if .Values.openshift -}}
{{- $ctx = omit $ctx "runAsUser" "runAsGroup" "fsGroup" -}}
{{- end -}}
{{- with $ctx -}}
{{ toYaml . }}
{{- end -}}
{{- end }}

{{- define "cf-codenavigator.secretName" -}}
{{- default (include "cf-codenavigator.fullname" .) .Values.secret.existingSecret -}}
{{- end }}

{{- define "cf-codenavigator.chartSecret" -}}
{{- if and (not .Values.secret.existingSecret) (or .Values.secret.apiKey .Values.secret.jwtSecret) -}}true{{- end -}}
{{- end }}

{{- define "cf-codenavigator.useSecret" -}}
{{- if or .Values.secret.existingSecret (include "cf-codenavigator.chartSecret" .) -}}true{{- end -}}
{{- end }}

{{- define "cf-codenavigator.claimName" -}}
{{- default (printf "%s-data" (include "cf-codenavigator.fullname" .)) .Values.persistence.existingClaim -}}
{{- end }}

{{- define "cf-codenavigator.httpPort" -}}
{{- $p := int (required "Set httpPort in values.yaml (the database port is httpPort + 1)." .Values.httpPort) -}}
{{- if or (lt $p 1) (gt $p 65534) -}}
{{- fail "httpPort must be between 1 and 65534." -}}
{{- end -}}
{{- $p -}}
{{- end }}

{{- define "cf-codenavigator.dbPort" -}}
{{- add (int (include "cf-codenavigator.httpPort" .)) 1 -}}
{{- end }}

{{- define "cf-codenavigator.serviceHttpPort" -}}
{{- default (include "cf-codenavigator.httpPort" .) .Values.service.httpPort -}}
{{- end }}

{{- define "cf-codenavigator.serviceDbPort" -}}
{{- default (include "cf-codenavigator.dbPort" .) .Values.service.dbPort -}}
{{- end }}
